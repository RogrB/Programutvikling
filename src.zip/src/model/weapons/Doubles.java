
package model.weapons;


public class Doubles extends Bullet {
    
    public Doubles(int x, int y, Weapon weapon) {
        super(
        x,
        y,
        weapon.PLAYER_DOUBLES);
    }        
    
}
