
package model.weapons;

public class Upgrade2 extends Bullet {
    
    public Upgrade2(int x, int y, Weapon weapon) {
        super(
        x,
        y,
        weapon.PLAYER_UPGRADED2);
    }    
        
    
}
