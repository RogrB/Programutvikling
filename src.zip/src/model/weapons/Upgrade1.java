package model.weapons;

public class Upgrade1 extends Bullet {
    
    public Upgrade1(int x, int y, Weapon weapon) {
        super(
        x,
        y,
        weapon.PLAYER_UPGRADED);
    }    
    
    
}
