public class GameStateManager {

//    private ArrayList<GameState> gameStates;
//    private int currentState;
//
//    public static final int MENUSTATE = 0;
//
//    public GameStateManager(){
//        gameStates = new ArrayList<GameState()>;
//
//        currentState = MENUSTATE;
//        gamestates.add(new MenuState(this));
//    }
//
//    public void setState(int state){
//        currentState = state;
//        gamesStates.get(currentState).init();
//    }
}
