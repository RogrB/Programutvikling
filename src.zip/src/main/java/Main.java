package main.java;

import controller.GameController;
import controller.UserInputs;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.GameModel;
import view.GameView;
import view.MenuView;
import view.ScreenController;

public class Main extends Application {

//    public static GameView gv = GameView.getInstance();
    //public static MenuView gm = MenuView.getInstance();
    public static String menuID = "MenuView";
    public static String menuFile = "MenuView.fxml";
    public static String gameID = "GameView";
    public static String gameFile = "GameView.fxml";

    @Override
    public void start(Stage primaryStage) throws Exception {
//        gv.setup();
        ScreenController main = new ScreenController();
        main.loadScreen(Main.menuID, Main.menuFile);
        main.loadScreen(Main.gameID, Main.gameFile);

        main.setScreen(Main.menuID);

        Group root = new Group();
        root.getChildren().addAll(main);
        primaryStage.setTitle("Working Title: Pippi");
        primaryStage.setResizable(false);
        primaryStage.setOnCloseRequest(e -> {
            System.out.println(java.lang.Thread.activeCount());
            Platform.exit();
            System.exit(0);});
        Scene scene = new Scene(root);
//        Scene scene = new Scene(gv.initGame());
        //Scene scene = new Scene(gm.initScene(primaryStage));

        UserInputs userInputs = new UserInputs(scene);

        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
