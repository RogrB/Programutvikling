package view;

public interface ControlledScreen {

    public void setScreenParent(ScreenController screenpage);
}
