package controller;

public class Camera {
}
